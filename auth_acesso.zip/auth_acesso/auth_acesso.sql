-- phpMyAdmin SQL Dump
-- version 3.4.11.1deb1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tempo de Geração: 19/07/2013 às 15:06:18
-- Versão do Servidor: 5.5.31
-- Versão do PHP: 5.4.6-1ubuntu1.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Banco de Dados: `auth_basico`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `clientes`
--

CREATE TABLE IF NOT EXISTS `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nome` char(45) NOT NULL,
  `email` varchar(50) DEFAULT NULL,
  `data_nasc` date DEFAULT NULL,
  `cpf` char(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=101 ;

--
-- Extraindo dados da tabela `clientes`
--

INSERT INTO `clientes` (`id`, `nome`, `email`, `data_nasc`, `cpf`) VALUES
(1, 'Erin Pate Skinner', 'dolor.vitae.dolor@mollisvitaeposuere.ca', '2013-10-07', '74426302285'),
(2, 'Leonard Martinez Hays', 'dignissim.magna.a@dolorvitae.org', '2012-08-22', '75278965048'),
(3, 'Aladdin Curry French', 'eu.augue@eutemporerat.org', '2012-10-28', '10376915676'),
(4, 'Chloe Macdonald Dalton', 'parturient.montes@Mauris.ca', '2013-05-12', '64444679077'),
(5, 'Mallory Sweet Strong', 'lorem@fringillaporttitor.ca', '2013-05-19', '15687101505'),
(6, 'Jermaine Pierce Woodward', 'mi.pede.nonummy@molestiearcu.ca', '2013-03-22', '36712502261'),
(7, 'Bell Raymond Pruitt', 'dignissim.tempor.arcu@nuncac.org', '2013-03-09', '64629428663'),
(8, 'Lydia Bell Whitfield', 'Sed@semper.com', '2013-12-02', '41962749289'),
(9, 'Tad Mason Graham', 'elit.erat@vestibulum.edu', '2012-06-08', '05642745964'),
(10, 'Felix Bradshaw Mccray', 'dui@elitCurabitursed.edu', '2013-09-16', '82071617437'),
(11, 'Idona Jensen Garrett', 'sem@Crasvulputate.com', '2014-01-08', '07941004794'),
(12, 'Wayne Ray Padilla', 'luctus.felis.purus@nonjustoProin.org', '2014-04-03', '60934465323'),
(13, 'Nelle Finch Cantu', 'placerat.eget@Donec.ca', '2012-05-29', '64704574060'),
(14, 'Maite Emerson Best', 'dui.augue@quisdiam.com', '2014-04-01', '04531857574'),
(15, 'Jada Holman Wilkins', 'dolor@tristiquealiquet.com', '2013-01-11', '88994190741'),
(16, 'Beverly Lane Lindsay', 'et.euismod@ametfaucibusut.com', '2013-10-22', '40194697135'),
(17, 'Hayden Clayton Foreman', 'enim@aliquamenimnec.edu', '2013-04-16', '72583040904'),
(18, 'Hadassah Leonard Key', 'dui.quis@augueidante.com', '2013-04-07', '72626859924'),
(19, 'Adrian Ballard Peters', 'enim.Curabitur@faucibus.com', '2012-07-13', '05459905306'),
(20, 'Phyllis Richmond Wynn', 'eget.laoreet@justoeuarcu.org', '2013-07-01', '62712888794'),
(21, 'Amelia Baird Barrera', 'id.ante@dignissim.org', '2012-06-09', '57625429482'),
(22, 'Whitney Mack Lamb', 'quam.Curabitur.vel@PraesentluctusCurabitur.org', '2012-06-26', '52403407001'),
(23, 'Myra Mcmahon Valentine', 'ac.mi@fringillami.edu', '2012-07-27', '42961419194'),
(24, 'Meghan Mann Powell', 'in@hendrerit.org', '2013-05-31', '86793386234'),
(25, 'Dana Pittman Petty', 'lectus@Phaselluselitpede.org', '2013-03-05', '87524105701'),
(26, 'Idola Thompson Riddle', 'fringilla@hendrerit.org', '2013-03-14', '77020701198'),
(27, 'Raja Pruitt Mccarthy', 'Fusce.dolor@magna.edu', '2013-03-31', '51166048953'),
(28, 'Mallory Gillespie Colon', 'convallis.erat.eget@amet.org', '2012-09-28', '46524277382'),
(29, 'Hayfa Greer Henry', 'egestas.a@facilisis.com', '2013-12-01', '85021348062'),
(30, 'Magee Bates Tate', 'sociosqu@Donec.edu', '2013-03-11', '07821266262'),
(31, 'Preston Leach Ryan', 'vitae.diam.Proin@eueleifendnec.edu', '2013-03-06', '71808899124'),
(32, 'Chiquita Espinoza Cleveland', 'molestie@molestieorci.edu', '2014-02-15', '05833411102'),
(33, 'Glenna Snider Joyce', 'varius@Pellentesque.ca', '2013-06-15', '22063384827'),
(34, 'Amir Delgado Fleming', 'Duis.dignissim.tempor@loremac.org', '2012-09-07', '75708650571'),
(35, 'Grace Bernard Gibbs', 'eget.ipsum@faucibusorciluctus.org', '2013-06-26', '15896025689'),
(36, 'Fuller Lowery Horton', 'Duis@fermentum.edu', '2012-08-11', '43856980668'),
(37, 'Fatima Romero Harding', 'Nam@pede.ca', '2014-05-20', '58741392820'),
(38, 'Vivian Ochoa Guthrie', 'Sed.eget.lacus@ac.edu', '2012-10-02', '14697438230'),
(39, 'Burke Travis Wade', 'urna.justo.faucibus@ut.com', '2012-06-23', '30640388585'),
(40, 'Lyle Willis Adkins', 'sit@semmollisdui.edu', '2012-10-28', '69571460872'),
(41, 'Christen Chan Fulton', 'bibendum.ullamcorper.Duis@semperNam.com', '2012-08-19', '16272275153'),
(42, 'Hashim Carney Griffin', 'lorem.eget.mollis@Maecenasiaculis.org', '2013-08-14', '52374402143'),
(43, 'Kessie Mckinney Arnold', 'lacinia.vitae.sodales@Sed.edu', '2013-08-29', '82526766619'),
(44, 'Charde Molina Clark', 'neque.vitae@elitCurabitur.com', '2013-08-19', '81916514846'),
(45, 'Xandra Gonzales Trujillo', 'magna.Praesent@justoeu.edu', '2012-09-17', '19211936396'),
(46, 'Rudyard Peterson Potts', 'euismod.et.commodo@imperdietornare.edu', '2013-04-25', '81541946599'),
(47, 'Nehru Collier Taylor', 'ultricies.dignissim.lacus@et.org', '2013-03-01', '62520398230'),
(48, 'Emma Dunlap Daniels', 'tempus.mauris.erat@ipsum.edu', '2014-04-18', '02199389688'),
(49, 'Hall Kent Burris', 'metus.vitae.velit@auctor.org', '2013-01-23', '95108326164'),
(50, 'Dora Merrill Price', 'tincidunt.orci@necmetusfacilisis.com', '2013-06-04', '64358868580'),
(51, 'Erich Spencer Mcknight', 'ante.dictum@metusfacilisis.edu', '2013-03-05', '08851425003'),
(52, 'Kaden Osborne Russell', 'ut.quam.vel@lectusCum.ca', '2013-05-27', '42855719657'),
(53, 'Shay Montoya Meadows', 'libero.est.congue@Donecfeugiatmetus.com', '2012-07-20', '31466145411'),
(54, 'Hammett Matthews House', 'Cras@Nunc.com', '2012-07-05', '95864431602'),
(55, 'Anthony Hess Hayden', 'est.mollis@magnis.org', '2012-12-20', '50774326426'),
(56, 'Melyssa Cotton Cline', 'amet.luctus@accumsanneque.edu', '2013-03-01', '75295730847'),
(57, 'Hiram Arnold Rollins', 'fermentum@consequat.edu', '2014-02-05', '88245469328'),
(58, 'Lilah Abbott Hicks', 'dui.Fusce.diam@cursus.com', '2012-09-03', '03787769583'),
(59, 'Linda Peters Cummings', 'in.tempus.eu@VivamusnisiMauris.ca', '2013-12-24', '77163102108'),
(60, 'Hu Burks Curtis', 'commodo@at.org', '2014-02-16', '94330159323'),
(61, 'Chester Whitley Bishop', 'non.magna@risusDonec.org', '2013-11-22', '66650771670'),
(62, 'Dawn Oconnor Le', 'velit.eget@acmetus.org', '2014-04-13', '50782796331'),
(63, 'Ulla Alexander Pitts', 'sit.amet@aauctornon.edu', '2014-01-28', '90902658616'),
(64, 'Carl Moreno Ortega', 'nec.tempus.scelerisque@semmagnanec.com', '2013-11-25', '59769734217'),
(65, 'James Boyer Rios', 'est.mollis@odio.org', '2012-07-12', '97758428814'),
(66, 'Deirdre Phillips James', 'volutpat.Nulla.dignissim@vellectus.ca', '2013-02-27', '89953037138'),
(67, 'Phillip French Mccormick', 'magna.malesuada@adipiscingfringilla.edu', '2012-09-06', '28270020367'),
(68, 'Cally Holman Mcneil', 'tincidunt@diamPellentesquehabitant.com', '2012-06-08', '71769124963'),
(69, 'Audrey Weiss Cook', 'ac.nulla@ac.ca', '2014-01-18', '37509969050'),
(70, 'Illiana Gonzales Cooke', 'neque@eu.edu', '2013-04-16', '53893817541'),
(71, 'Joshua Perry Stark', 'faucibus@pulvinararcuet.com', '2013-05-09', '70974297200'),
(72, 'Jade Nicholson Griffin', 'aliquet@aliquamerosturpis.ca', '2013-09-13', '46161942622'),
(73, 'Yetta York Griffith', 'ligula.Donec.luctus@maurissitamet.org', '2014-05-14', '54869502173'),
(74, 'Tate Donaldson Boyd', 'fames@amet.com', '2014-01-29', '56585515307'),
(75, 'Bell Moreno Chapman', 'Duis.ac.arcu@Sed.com', '2012-10-22', '35074275105'),
(76, 'Jakeem Mendoza Clayton', 'sit@Proinnonmassa.org', '2012-08-01', '29790319624'),
(77, 'Thor Maddox Barnes', 'ad.litora.torquent@nonummyFusce.edu', '2013-04-15', '03168788264'),
(78, 'Shea Talley Hester', 'mollis.lectus@Morbiaccumsan.edu', '2013-05-17', '45294893145'),
(79, 'Caryn Mayo Washington', 'Vestibulum@turpisegestasFusce.edu', '2013-12-19', '62601546495'),
(80, 'Jillian Hill Brennan', 'velit.dui.semper@diamat.com', '2013-08-31', '87748342512'),
(81, 'Mari Roth Lynch', 'nulla@eutemporerat.com', '2013-05-16', '32297705051'),
(82, 'Gray Huffman Stephens', 'leo@gravidasitamet.com', '2013-02-16', '90527370248'),
(83, 'Lana Schroeder Carver', 'Proin.dolor.Nulla@inhendreritconsectetuer.ca', '2013-08-08', '46350841726'),
(84, 'Brody Contreras Riley', 'orci.in.consequat@etmalesuada.edu', '2013-09-12', '52648557243'),
(85, 'Ashely Villarreal Whitley', 'magnis.dis@cubiliaCurae;Phasellus.ca', '2013-04-12', '19281458808'),
(86, 'Arthur Montoya Clemons', 'aliquam.eu.accumsan@faucibus.org', '2014-01-01', '75106000502'),
(87, 'Kiara Clark Duran', 'nec.euismod.in@enimconsequat.org', '2013-09-22', '10600228331'),
(88, 'Xerxes Bolton Newman', 'augue@metus.edu', '2013-02-20', '36252489421'),
(89, 'Zia Hobbs Christensen', 'mi.lorem@ipsum.ca', '2014-01-20', '02022183314'),
(90, 'Kylan Jennings Cash', 'egestas.Fusce.aliquet@orcitincidunt.ca', '2013-11-18', '37157573093'),
(91, 'Shafira Beasley Mcgowan', 'litora.torquent.per@liberomaurisaliquam.edu', '2012-10-01', '13269787820'),
(92, 'Portia Mcdaniel Roach', 'metus.sit.amet@actellus.ca', '2014-05-07', '85714873163'),
(93, 'Dean Santos Riddle', 'tellus.Aenean@Morbisitamet.com', '2014-03-13', '41558138283'),
(94, 'Arsenio Neal Tate', 'feugiat.tellus.lorem@vel.org', '2013-12-21', '68200086559'),
(95, 'Sacha Allen Beasley', 'eleifend.non@faucibusutnulla.ca', '2012-11-05', '76607396123'),
(96, 'Pascale Weaver Castro', 'nec.urna.et@eget.ca', '2014-01-05', '85373386971'),
(97, 'Rajah Lopez Sampson', 'Proin.non@Sedcongue.org', '2012-10-11', '18856865895'),
(98, 'Melanie Reid Bray', 'ultricies@Phasellusdolor.com', '2013-09-10', '13121605363'),
(99, 'Sybill Rodriquez Conrad', 'Aliquam.ornare.libero@sedliberoProin.ca', '2013-04-11', '43800610154'),
(100, 'Kaseem Mueller Sharp', 'varius.et.euismod@eratVivamusnisi.ca', '2012-10-01', '56585302688');

-- --------------------------------------------------------

--
-- Estrutura da tabela `groups`
--

CREATE TABLE IF NOT EXISTS `groups` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `groups`
--

INSERT INTO `groups` (`id`, `name`, `created`, `modified`) VALUES
(1, 'admins', '2013-06-22 17:05:29', '2013-06-22 17:05:29'),
(2, 'gerentes', '2013-06-23 10:57:28', '2013-06-23 10:57:28'),
(3, 'usuarios', '2013-06-24 20:03:29', '2013-06-24 20:03:29');

-- --------------------------------------------------------

--
-- Estrutura da tabela `privileges`
--

CREATE TABLE IF NOT EXISTS `privileges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_id` int(11) NOT NULL,
  `controller` varchar(50) NOT NULL,
  `action` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `controller` (`controller`,`action`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=16 ;

--
-- Extraindo dados da tabela `privileges`
--

INSERT INTO `privileges` (`id`, `group_id`, `controller`, `action`) VALUES
(1, 3, 'clientes', 'index'),
(2, 3, 'clientes', 'view'),
(3, 2, 'clientes', 'admin_add'),
(4, 2, 'clientes', 'admin_edit'),
(5, 2, 'clientes', 'admin_delete'),
(6, 1, 'users', 'index'),
(7, 1, 'users', 'view'),
(8, 1, 'users', 'add'),
(9, 1, 'users', 'edit'),
(10, 1, 'users', 'delete'),
(11, 1, 'groups', 'index'),
(12, 1, 'groups', 'view'),
(13, 1, 'groups', 'add'),
(14, 1, 'groups', 'edit'),
(15, 1, 'groups', 'delete');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` char(40) NOT NULL,
  `activated` tinyint(1) NOT NULL DEFAULT '1',
  `group_id` int(11) NOT NULL,
  `created` datetime DEFAULT NULL,
  `modified` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `activated`, `group_id`, `created`, `modified`) VALUES
(1, 'admin', '7e5cfdea87bc38b1ab7de861d1126c9ef4a26ac1', 0, 1, '2013-07-19 14:33:46', '2013-07-19 14:33:46'),
(2, 'gerente', '70892b18ea028d3675cacaa5bb954d9f206983e0', 0, 2, '2013-07-19 14:45:50', '2013-07-19 14:45:50'),
(3, 'usuario', '9a4a8dac401230fc65f4cf43da1a6d3470c4d341', 0, 3, '2013-07-19 14:46:03', '2013-07-19 14:46:03');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
